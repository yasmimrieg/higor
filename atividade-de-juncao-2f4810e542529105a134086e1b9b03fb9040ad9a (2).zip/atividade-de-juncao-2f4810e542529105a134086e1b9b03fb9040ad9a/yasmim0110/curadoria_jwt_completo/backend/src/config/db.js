const { Pool } = require("pg");
const pool = new Pool({
    host: 'aws-0-us-east-2.pooler.supabase.com',
    user: 'postgres.iybydskhsuvhzvpkkjbr',
    password: 'Yasmim2009',
    database: 'postgres',
    port:6543,
    ssl:{
      rejectUnauthorized: false
    }
  });
  
  module.exports = pool;